package com.example.mongodbuserapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MongoDbUserAppApplication {

    public static void main(String[] args) {
        SpringApplication.run(MongoDbUserAppApplication.class, args);
    }
} 