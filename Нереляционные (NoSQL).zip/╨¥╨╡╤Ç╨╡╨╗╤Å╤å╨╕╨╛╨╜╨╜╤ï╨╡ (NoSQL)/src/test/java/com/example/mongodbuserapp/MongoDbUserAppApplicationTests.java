package com.example.mongodbuserapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MongoDbUserAppApplicationTests {

    @Test
    void contextLoads() {
        // Тест проверяет, что контекст Spring Boot загружается корректно
    }
} 