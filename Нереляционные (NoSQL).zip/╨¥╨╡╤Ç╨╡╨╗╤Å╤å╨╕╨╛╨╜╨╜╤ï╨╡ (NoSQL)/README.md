# Spring Boot MongoDB User Application

Простое Spring Boot приложение для работы с пользователями в MongoDB.

## Требования

- Java 17 или выше
- Maven 3.6 или выше
- MongoDB 4.4 или выше

## Установка и запуск

### 1. Установка MongoDB

Убедитесь, что MongoDB установлен и запущен на вашей системе:

```bash
# Для macOS (с помощью Homebrew)
brew install mongodb-community
brew services start mongodb-community

# Для Ubuntu/Debian
sudo apt-get install mongodb
sudo systemctl start mongodb

# Для Windows
# Скачайте и установите MongoDB с официального сайта
```

### 2. Запуск приложения

```bash
# Клонируйте репозиторий (если необходимо)
# cd /path/to/project

# Сборка проекта
mvn clean install

# Запуск приложения
mvn spring-boot:run
```

Приложение будет доступно по адресу: http://localhost:8080

## API Endpoints

### Основные CRUD операции

| Метод | URL | Описание |
|-------|-----|----------|
| POST | `/api/users` | Создать нового пользователя |
| GET | `/api/users` | Получить всех пользователей |
| GET | `/api/users/{id}` | Получить пользователя по ID |
| PUT | `/api/users/{id}` | Обновить пользователя |
| DELETE | `/api/users/{id}` | Удалить пользователя |

### Дополнительные операции поиска

| Метод | URL | Описание |
|-------|-----|----------|
| GET | `/api/users/email/{email}` | Найти пользователя по email |
| GET | `/api/users/search/name/{name}` | Найти пользователей по имени |
| GET | `/api/users/search/age/{age}` | Найти пользователей по возрасту |
| GET | `/api/users/search/age/gt/{age}` | Найти пользователей старше указанного возраста |
| GET | `/api/users/search/age/lt/{age}` | Найти пользователей младше указанного возраста |
| GET | `/api/users/search/age/range?min={min}&max={max}` | Найти пользователей в диапазоне возрастов |
| GET | `/api/users/search/name/contains/{name}` | Найти пользователей по части имени |
| GET | `/api/users/health` | Проверка состояния API |

## Примеры использования

### Создание пользователя

```bash
curl -X POST http://localhost:8080/api/users \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Иван Иванов",
    "email": "ivan@example.com",
    "age": 25
  }'
```

### Получение всех пользователей

```bash
curl -X GET http://localhost:8080/api/users
```

### Получение пользователя по ID

```bash
curl -X GET http://localhost:8080/api/users/{id}
```

### Обновление пользователя

```bash
curl -X PUT http://localhost:8080/api/users/{id} \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Иван Петров",
    "email": "ivan.petrov@example.com",
    "age": 26
  }'
```

### Удаление пользователя

```bash
curl -X DELETE http://localhost:8080/api/users/{id}
```

### Поиск пользователей

```bash
# По имени
curl -X GET http://localhost:8080/api/users/search/name/Иван

# По возрасту
curl -X GET http://localhost:8080/api/users/search/age/25

# По диапазону возрастов
curl -X GET "http://localhost:8080/api/users/search/age/range?min=20&max=30"
```

## Структура проекта

```
src/
├── main/
│   ├── java/
│   │   └── com/example/mongodbuserapp/
│   │       ├── MongoDbUserAppApplication.java
│   │       ├── controller/
│   │       │   └── UserController.java
│   │       ├── model/
│   │       │   └── User.java
│   │       ├── repository/
│   │       │   └── UserRepository.java
│   │       ├── service/
│   │       │   └── UserService.java
│   │       └── exception/
│   │           └── GlobalExceptionHandler.java
│   └── resources/
│       └── application.properties
└── test/
    └── java/
        └── com/example/mongodbuserapp/
```

## Конфигурация

Основные настройки находятся в файле `src/main/resources/application.properties`:

- MongoDB host: localhost
- MongoDB port: 27017
- Database name: userdb
- Server port: 8080

## Валидация данных

Приложение включает валидацию входных данных:

- **name**: обязательное поле, не может быть пустым
- **email**: обязательное поле, должно быть валидным email адресом
- **age**: обязательное поле, должно быть положительным числом

## Тестирование

Для тестирования API можно использовать:

1. **Postman** - импортируйте коллекцию запросов
2. **curl** - используйте примеры выше
3. **Swagger UI** - доступен по адресу http://localhost:8080/swagger-ui.html (если добавлен springdoc-openapi)

## Возможные проблемы

1. **MongoDB не запущен**: Убедитесь, что MongoDB запущен и доступен на порту 27017
2. **Порт занят**: Измените порт в application.properties
3. **Ошибки валидации**: Проверьте формат данных в запросах

## Дополнительные возможности

- Кросс-доменные запросы (CORS)
- Глобальная обработка исключений
- Валидация входных данных
- Логирование операций
- Поиск по различным критериям 